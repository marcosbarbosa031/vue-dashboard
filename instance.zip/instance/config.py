SECRET_KEY = '4D*lSIYQY_u14)aV'
SQLALCHEMY_DATABASE_URI = "mysql+pymysql://root@localhost/vue-dashboard"
# SQLALCHEMY_DATABASE_URI = "mysql+pymysql://admingpm:82xx.Wn+.(Uu@gpmsolutions.com.br/sqlgmp"


